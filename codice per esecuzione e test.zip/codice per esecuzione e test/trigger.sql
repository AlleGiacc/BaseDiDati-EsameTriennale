-- limite delle carte in un mazzo (INSERT)
CREATE OR REPLACE FUNCTION limite_carte() RETURNS TRIGGER
AS $limite_carte$
    BEGIN
        IF (NEW.n_carte < 40) THEN
            RAISE EXCEPTION 'Minimum limit of cards in the deck is 40';
        ELSEIF (NEW.n_carte > 60) THEN
            RAISE EXCEPTION 'Maximum limit of cards in the deck is 60';
        END IF;
        RETURN NULL;
    END;
$limite_carte$ LANGUAGE plpgsql;

CREATE TRIGGER limite_carte
BEFORE INSERT ON mazzo
FOR EACH ROW EXECUTE FUNCTION limite_carte();

-- limite delle carte in un mazzo (UPDATE)
CREATE OR REPLACE FUNCTION limite_carte_update() RETURNS TRIGGER
AS $limite_carte_update$
    BEGIN
        IF (NEW.n_carte < 40) THEN
            RAISE EXCEPTION 'Minimum limit of cards in the deck is 40';
        ELSEIF (NEW.n_carte > 60) THEN
            RAISE EXCEPTION 'Maximum limit of cards in the deck is 60';
        END IF;
        RETURN NULL;
    END;
$limite_carte_update$ LANGUAGE plpgsql;

CREATE TRIGGER limite_carte_update
BEFORE UPDATE ON mazzo
FOR EACH ROW EXECUTE FUNCTION limite_carte_update();

-- aggiornamento dell’elo in base al valore.
CREATE OR REPLACE FUNCTION elo() RETURNS TRIGGER
AS $elo$
    BEGIN
        IF (OLD.elo != NEW.elo) THEN
            IF (NEW.elo < 200) THEN
                UPDATE utente SET id_rank=1 WHERE nickname=NEW.nickname;
            ELSEIF (NEW.elo >= 200 AND NEW.elo < 700) THEN
                UPDATE utente SET id_rank=2 WHERE nickname=NEW.nickname;
            ELSEIF (NEW.elo >= 700 AND NEW.elo < 1200) THEN
                UPDATE utente SET id_rank=3 WHERE nickname=NEW.nickname;
            ELSEIF (NEW.elo >= 1200 AND NEW.elo < 1700) THEN
                UPDATE utente SET id_rank=4 WHERE nickname=NEW.nickname;
            ELSEIF (NEW.elo >= 1700) THEN
                UPDATE utente SET id_rank=5 WHERE nickname=NEW.nickname;
            END IF;
        END IF;
        RETURN NULL;
    END;
$elo$ LANGUAGE plpgsql;

CREATE TRIGGER elo
AFTER UPDATE ON utente
FOR EACH ROW EXECUTE FUNCTION elo();

-- limite massimo di apparizioni di una carta in deck (INSERT)
CREATE OR REPLACE FUNCTION limite_3_carte_mazzo() RETURNS TRIGGER
AS $limite_3_carte_mazzo$
DECLARE boxid integer;
DECLARE altro_n integer;
    BEGIN

	IF (NEW.n > 3) THEN
            RAISE EXCEPTION 'Maximum limit for the same card reached';
        END IF;

	SELECT
		a.id_carta_carta_coll INTO boxid
	FROM
		apparizioni AS a, carta_collezione AS cc, carta AS c, mazzo AS m
	WHERE 
		m.id=a.id_mazzo AND a.id_carta_carta_coll=cc.id_carta AND
		a.id_rarita_carta_coll=cc.id_rarita_carta AND a.id_utente_carta_coll=cc.id_utente AND
		c.id=cc.id_carta AND cc.id_rarita_carta=c.id_rarita AND
		c.nome=(SELECT c1.nome
			FROM carta_collezione AS cc1, carta AS c1
			WHERE c1.id=cc1.id_carta AND cc1.id_rarita_carta=c1.id_rarita AND
			cc1.id_carta=NEW.id_carta_carta_coll);                                                                                                      
	
	SELECT
		a.n INTO altro_n
	FROM
		apparizioni AS a
	WHERE
		a.id_carta_carta_coll=boxid;

	IF( (NEW.n + altro_n) > 3) THEN
		RAISE EXCEPTION 'Maximum limit for the same card reached';
	END IF;
                                    
        RETURN NULL;
    END;
$limite_3_carte_mazzo$ LANGUAGE plpgsql;
 
CREATE TRIGGER limite_3_carte_mazzo
AFTER INSERT ON apparizioni
FOR EACH ROW EXECUTE FUNCTION limite_3_carte_mazzo();

-- limite massimo di apparizioni di una carta in deck (UPDATE)
CREATE OR REPLACE FUNCTION limite_3_carte_mazzo_update() RETURNS TRIGGER
AS $limite_3_carte_mazzo_update$
DECLARE boxid integer;
DECLARE altro_n integer;
    BEGIN
	SELECT
		a.id_carta_carta_coll INTO boxid
	FROM
		apparizioni AS a, carta_collezione AS cc, carta AS c, mazzo AS m
	WHERE
		m.id=a.id_mazzo AND a.id_carta_carta_coll=cc.id_carta AND
		a.id_rarita_carta_coll=cc.id_rarita_carta AND a.id_utente_carta_coll=cc.id_utente AND
		c.id=cc.id_carta AND cc.id_rarita_carta=c.id_rarita AND
		a.id_carta_carta_coll <> NEW.id_carta_carta_coll AND
		c.nome=(SELECT c1.nome
			FROM carta_collezione AS cc1, carta AS c1
			WHERE c1.id=cc1.id_carta AND cc1.id_rarita_carta=c1.id_rarita
			AND cc1.id_carta=NEW.id_carta_carta_coll);
 
	SELECT
		a.n INTO altro_n
	FROM
		apparizioni AS a
	WHERE
		a.id_carta_carta_coll=boxid;
                  
	IF (NEW.n > 3) THEN
		RAISE EXCEPTION 'Maximum limit for the same card reached';
	END IF;
	                  
	IF ((NEW.n + altro_n) > 3) THEN
		RAISE EXCEPTION 'Maximum limit for the same card reached';
	END IF;                      
        RETURN NULL;
    END;
$limite_3_carte_mazzo_update$ LANGUAGE plpgsql;

CREATE TRIGGER limite_3_carte_mazzo_update
AFTER UPDATE ON apparizioni
FOR EACH ROW EXECUTE FUNCTION limite_3_carte_mazzo_update();

-- limite massimo di 5 buste a settimana.
CREATE OR REPLACE FUNCTION limite_5_buste() RETURNS TRIGGER
AS $limite_5_buste$
DECLARE cronologia integer;
    BEGIN
        
        SELECT
            COUNT(*) INTO cronologia
        FROM
            venire
        WHERE
            id_utente_comprare=NEW.id_utente_comprare AND seriale_busta=NEW.seriale_busta AND
            data_comprare BETWEEN date_trunc('week', current_date) AND CURRENT_DATE;
        
        IF (cronologia > 5) THEN
            RAISE EXCEPTION 'Maximum limit of purchases reached';
        END IF;
        
        RETURN NULL;
    END;
$limite_5_buste$ LANGUAGE plpgsql;
 
CREATE TRIGGER limite_5_buste
AFTER INSERT ON venire
FOR EACH ROW EXECUTE FUNCTION limite_5_buste();

