-- INDICE DELLE TABELLE
--
-- 001 -> rank
-- 002 -> utente
-- 003 -> amicizia
-- 004 -> amichevole
-- 005 -> torneo
-- 006 -> classificata
-- 007.1 -> partecipa_amichevole
-- 007.2 -> partecipa_classificata
-- 008 -> mazzo
-- 009 -> rarita
-- 010 -> carta
-- 011 -> carta_collezione
-- 012 -> mercato
-- 013 -> apparizioni
-- 014 -> espansione
-- 015 -> compare
-- 016 -> busta
-- 017 -> comprare
-- 018 -> venire
-- 019 -> s_presenta
-- 020 -> acquistata
-- 021 -> n_presenta
-- 022 -> categoria
-- 023 -> magie_trappole
-- 024 -> attributo
-- 025 -> sotto_tipo
-- 026 -> mostro

-- TABELLE
--
-- 001
-- rank
CREATE TABLE IF NOT EXISTS rank (
  id BIGSERIAL NOT NULL,
  nome varchar(64) NOT NULL,
  range_min integer NOT NULL,
  range_max integer NOT NULL
);

-- 002
-- utente
CREATE TABLE IF NOT EXISTS utente (
  id BIGSERIAL NOT NULL,
  id_rank integer NOT NULL,
  nome varchar(64) DEFAULT NULL,
  nickname varchar(255) NOT NULL,
  elo integer DEFAULT NULL,
  gemme integer DEFAULT NULL
);

-- 003
-- amicizia
CREATE TABLE IF NOT EXISTS amicizia (
  id_utente_1 integer NOT NULL,
  id_utente_2 integer NOT NULL
);

-- 004
-- amichevole
CREATE TABLE IF NOT EXISTS amichevole (
  id BIGSERIAL NOT NULL,
  id_utente_vincitore integer NOT NULL,
  data date DEFAULT NULL
);

-- 005
-- torneo
CREATE TABLE IF NOT EXISTS torneo (
  id integer NOT NULL
);

-- 006
-- classificata
CREATE TABLE IF NOT EXISTS classificata (
  id BIGSERIAL NOT NULL,
  id_utente_vincitore integer NOT NULL,
  id_torneo integer NOT NULL,
  data date DEFAULT NULL,
  premio integer DEFAULT NULL
);

-- 007.1
-- partecipa_amichevole
CREATE TABLE IF NOT EXISTS partecipa_amichevole (
  id_utente integer NOT NULL,
  id_amichevole integer DEFAULT NULL
);

-- 007.2
-- partecipa_classificata
CREATE TABLE IF NOT EXISTS partecipa_classificata (
  id_utente integer NOT NULL,
  id_classificata integer DEFAULT NULL
);

-- 008
-- mazzo
CREATE TABLE IF NOT EXISTS mazzo (
  id BIGSERIAL NOT NULL,
  id_utente integer NOT NULL,
  nome varchar(255) NOT NULL,
  n_carte integer DEFAULT NULL
);

-- 009
-- rarita
CREATE TABLE IF NOT EXISTS rarita (
  id BIGSERIAL NOT NULL,
  nome varchar(64) NOT NULL
);

-- 010
-- carta
CREATE TABLE IF NOT EXISTS carta (
  id BIGSERIAL NOT NULL,
  id_rarita integer NOT NULL,
  nome varchar(64) NOT NULL,
  descrizione_effetto varchar(255) DEFAULT NULL,
  immagine varchar(255) DEFAULT NULL
);

-- 011
-- carta_collezione
CREATE TABLE IF NOT EXISTS carta_collezione (
  id_utente integer NOT NULL,
  id_carta integer NOT NULL,
  id_rarita_carta integer NOT NULL,
  qnt integer NOT NULL
);

-- 012
-- mercato
CREATE TABLE IF NOT EXISTS mercato (
  id_utente integer NOT NULL,
  id_utente_carta_coll integer NOT NULL,
  id_carta_carta_coll integer NOT NULL,
  id_rarita_carta_coll integer NOT NULL,
  qnt integer DEFAULT NULL,
  prezzo varchar(64) DEFAULT NULL
);

-- 013
-- apparizioni
CREATE TABLE IF NOT EXISTS apparizioni (
  id_mazzo integer NOT NULL,
  id_utente_carta_coll integer NOT NULL,
  id_carta_carta_coll integer NOT NULL,
  id_rarita_carta_coll integer NOT NULL,
  n integer NOT NULL
);

-- 014
-- espansione
CREATE TABLE IF NOT EXISTS espansione (
  id BIGSERIAL NOT NULL,
  nome varchar(255) NOT NULL,
  anno integer DEFAULT NULL
);

-- 015
-- compare
CREATE TABLE IF NOT EXISTS compare (
  id_espansione integer NOT NULL,
  id_carta integer NOT NULL,
  id_rarita_carta integer NOT NULL
);

-- 016
-- busta
CREATE TABLE IF NOT EXISTS busta (
  seriale varchar(255) NOT NULL,
  id_espansione integer NOT NULL,
  is_speciale BOOLEAN NOT NULL
);

-- 017
-- comprare
CREATE TABLE IF NOT EXISTS comprare (
  data date NOT NULL,
  id_utente integer NOT NULL
);

-- 018
-- venire
CREATE TABLE IF NOT EXISTS venire (
  seriale_busta varchar(255) NOT NULL,
  id_utente_comprare integer NOT NULL,
  data_comprare date NOT NULL
);

-- 019
-- s_presenta
CREATE TABLE IF NOT EXISTS s_presenta (
  seriale varchar(255) NOT NULL,
  id_carta integer NOT NULL,
  id_rarita_carta integer NOT NULL
);

-- 020
-- acquistata
CREATE TABLE IF NOT EXISTS acquistata (
  seriale varchar(255) NOT NULL,
  id_utente integer NOT NULL
);

-- 021
-- n_presenta
CREATE TABLE IF NOT EXISTS n_presenta (
  seriale varchar(255) NOT NULL,
  id_carta integer NOT NULL,
  id_rarita_carta integer NOT NULL
);

-- 022
-- categoria
CREATE TABLE IF NOT EXISTS categoria (
  id BIGSERIAL NOT NULL,
  nome varchar(255) NOT NULL
);

-- 023
-- magie_trappole
CREATE TABLE IF NOT EXISTS magie_trappole (
  id_carta integer NOT NULL,
  id_rarita_carta integer NOT NULL,
  id_categoria integer NOT NULL
);

-- 024
-- attributo
CREATE TABLE IF NOT EXISTS attributo (
  id BIGSERIAL NOT NULL,
  nome varchar(255) NOT NULL
);

-- 025
-- sotto_tipo
CREATE TABLE IF NOT EXISTS sotto_tipo (
  id BIGSERIAL NOT NULL,
  nome varchar(255) NOT NULL
);

-- 026
-- mostro
CREATE TYPE mostri_livello AS ENUM ('mostro_normale', 'mostro_effetto', 'mostro_fusione', 'mostro_synchro', 'mostro_rituale');

CREATE TYPE mostri AS ENUM ('livello', 'xyz', 'link');

CREATE TABLE IF NOT EXISTS mostro (
  id_carta integer NOT NULL,
  id_rarita_carta integer NOT NULL,
  tipologia_mostro mostri DEFAULT NULL,
  tipologia_mostro_livello mostri_livello DEFAULT NULL,
  link_level integer DEFAULT NULL,
  rango integer DEFAULT NULL,
  id_sotto_tipo integer NOT NULL,
  id_attributo integer NOT NULL
);


