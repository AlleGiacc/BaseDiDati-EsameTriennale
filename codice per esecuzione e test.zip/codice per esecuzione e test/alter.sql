-- INDICE DELLE TABELLE
--
-- 001 -> rank
-- 002 -> utente
-- 003 -> amicizia
-- 004 -> amichevole
-- 005 -> torneo
-- 006 -> classificata
-- 007.1 -> partecipa_amichevole
-- 007.2 -> partecipa_classificata
-- 008 -> mazzo
-- 009 -> rarita
-- 010 -> carta
-- 011 -> carta_collezione
-- 012 -> mercato
-- 013 -> apparizioni
-- 014 -> espansione
-- 015 -> compare
-- 016 -> busta
-- 017 -> comprare
-- 018 -> venire
-- 019 -> s_presenta
-- 020 -> acquistata
-- 021 -> n_presenta
-- 022 -> categoria
-- 023 -> magie_trappole
-- 024 -> attributo
-- 025 -> sotto_tipo
-- 026 -> mostro

-- TABELLE
--
-- 001
-- rank
ALTER TABLE rank
	ADD PRIMARY KEY (id),
	ADD CONSTRAINT unica_rank UNIQUE (nome, range_min, range_max);

-- 002
-- utente
ALTER TABLE utente
	ADD PRIMARY KEY (id),
	ADD CONSTRAINT unica_utente UNIQUE (nickname),
  ADD CONSTRAINT fk_rank FOREIGN KEY (id_rank) REFERENCES rank(id) ON DELETE CASCADE;


-- 003
-- amicizia
ALTER TABLE amicizia
	ADD PRIMARY KEY (id_utente_1, id_utente_2),
  ADD CONSTRAINT fk_amicizia_1 FOREIGN KEY (id_utente_1) REFERENCES utente(id) ON UPDATE CASCADE ON DELETE CASCADE,
  ADD CONSTRAINT fk_amicizia_2 FOREIGN KEY (id_utente_2) REFERENCES utente(id) ON UPDATE CASCADE ON DELETE CASCADE;

-- 004
-- amichevole
ALTER TABLE amichevole
	ADD PRIMARY KEY (id),
  ADD CONSTRAINT fk_amichevole_1 FOREIGN KEY (id_utente_vincitore) REFERENCES utente(id) ON UPDATE CASCADE ON DELETE CASCADE,
  ADD CONSTRAINT unica_amichevole UNIQUE (id_utente_vincitore, data);

-- 005
-- torneo
ALTER TABLE torneo
	ADD PRIMARY KEY (id);

-- 006
-- classificata
ALTER TABLE classificata
	ADD PRIMARY KEY (id),
    ADD CONSTRAINT fk_classificata_1 FOREIGN KEY (id_utente_vincitore) REFERENCES utente(id) ON UPDATE CASCADE ON DELETE CASCADE,
    ADD CONSTRAINT fk_classificata_2 FOREIGN KEY (id_torneo) REFERENCES torneo(id) ON UPDATE CASCADE ON DELETE CASCADE,
    ADD CONSTRAINT unica_classificata UNIQUE (id_utente_vincitore, data);

-- 007.1
-- partecipa_amichevole
ALTER TABLE partecipa_amichevole
	ADD PRIMARY KEY (id_utente, id_amichevole),
    ADD CONSTRAINT fk_partecipa_amichevole_1 FOREIGN KEY (id_utente) REFERENCES utente(id) ON UPDATE CASCADE ON DELETE CASCADE,
    ADD CONSTRAINT fk_partecipa_amichevole_2 FOREIGN KEY (id_amichevole) REFERENCES amichevole(id) ON UPDATE CASCADE ON DELETE CASCADE;

-- 007.2
-- partecipa_classificata
ALTER TABLE partecipa_classificata
	ADD PRIMARY KEY (id_utente, id_classificata),
    ADD CONSTRAINT fk_partecipa_amichevole_1 FOREIGN KEY (id_utente) REFERENCES utente(id) ON UPDATE CASCADE ON DELETE CASCADE,
    ADD CONSTRAINT fk_partecipa_amichevole_2 FOREIGN KEY (id_classificata) REFERENCES classificata(id) ON UPDATE CASCADE ON DELETE CASCADE;

-- 008
-- mazzo
ALTER TABLE mazzo
	ADD PRIMARY KEY (id),
  ADD CONSTRAINT fk_mazzo_1 FOREIGN KEY (id_utente) REFERENCES utente(id) ON UPDATE CASCADE ON DELETE CASCADE,
  ADD CONSTRAINT unica_mazzo UNIQUE (id_utente, nome);

-- 009
-- rarita
ALTER TABLE rarita
	ADD PRIMARY KEY (id),
    ADD CONSTRAINT unica_rarita UNIQUE (nome);

-- 010
-- carta
ALTER TABLE carta
	ADD PRIMARY KEY (id, id_rarita),
	ADD CONSTRAINT fk_carta_1 FOREIGN KEY (id_rarita) REFERENCES rarita(id) ON UPDATE CASCADE ON DELETE CASCADE,
    ADD CONSTRAINT unica_carta UNIQUE (id_rarita, nome);

-- 011
-- carta_collezione
ALTER TABLE carta_collezione
	ADD PRIMARY KEY (id_utente, id_carta, id_rarita_carta),
  ADD CONSTRAINT fk_carta_collezione_1 FOREIGN KEY (id_utente) REFERENCES utente(id) ON UPDATE CASCADE ON DELETE CASCADE,
  ADD CONSTRAINT fk_carta_collezione_2 FOREIGN KEY (id_carta, id_rarita_carta) REFERENCES carta(id, id_rarita) ON UPDATE CASCADE ON DELETE CASCADE;

-- 012
-- mercato
ALTER TABLE mercato
	ADD PRIMARY KEY (id_utente, id_utente_carta_coll, id_carta_carta_coll, id_rarita_carta_coll),
  ADD CONSTRAINT fk_mercato_1 FOREIGN KEY (id_utente) REFERENCES utente(id) ON UPDATE CASCADE ON DELETE CASCADE,
  ADD CONSTRAINT fk_mercato_2 FOREIGN KEY (id_utente_carta_coll, id_carta_carta_coll, id_rarita_carta_coll) REFERENCES carta_collezione(id_utente, id_carta, id_rarita_carta) ON UPDATE CASCADE ON DELETE CASCADE;

-- 013
-- apparizioni
ALTER TABLE apparizioni
	ADD PRIMARY KEY (id_mazzo, id_utente_carta_coll, id_carta_carta_coll, id_rarita_carta_coll),
  ADD CONSTRAINT fk_apparizioni_1 FOREIGN KEY (id_utente_carta_coll, id_carta_carta_coll, id_rarita_carta_coll) REFERENCES carta_collezione(id_utente, id_carta, id_rarita_carta) ON UPDATE CASCADE ON DELETE CASCADE;

-- 014
-- espansione
ALTER TABLE espansione
	ADD PRIMARY KEY (id),
  ADD CONSTRAINT unica_espansione UNIQUE (nome);

-- 015
-- compare
ALTER TABLE compare
	ADD PRIMARY KEY (id_espansione, id_carta, id_rarita_carta),
  ADD CONSTRAINT fk_compare_1 FOREIGN KEY (id_espansione) REFERENCES espansione(id) ON UPDATE CASCADE ON DELETE CASCADE,
  ADD CONSTRAINT fk_compare_2 FOREIGN KEY (id_carta, id_rarita_carta) REFERENCES carta(id, id_rarita) ON UPDATE CASCADE ON DELETE CASCADE;

-- 016
-- busta
ALTER TABLE busta
	ADD PRIMARY KEY (seriale),
  ADD CONSTRAINT fk_busta_1 FOREIGN KEY (id_espansione) REFERENCES espansione(id) ON UPDATE CASCADE ON DELETE CASCADE,
  ADD CONSTRAINT unica_busta UNIQUE (seriale, id_espansione);

-- 017
-- comprare
ALTER TABLE comprare
	ADD PRIMARY KEY (data, id_utente),
  ADD CONSTRAINT fk_comprare_1 FOREIGN KEY (id_utente) REFERENCES utente(id) ON UPDATE CASCADE ON DELETE CASCADE;

-- 018
-- venire
ALTER TABLE venire
	ADD PRIMARY KEY (seriale_busta, id_utente_comprare, data_comprare),
  ADD CONSTRAINT fk_venire_1 FOREIGN KEY (seriale_busta) REFERENCES busta(seriale) ON UPDATE CASCADE ON DELETE CASCADE,
  ADD CONSTRAINT fk_venire_2 FOREIGN KEY (id_utente_comprare, data_comprare) REFERENCES comprare(id_utente, data) ON UPDATE CASCADE ON DELETE CASCADE;

-- 019
-- s_presenta
ALTER TABLE s_presenta
	ADD PRIMARY KEY (seriale, id_carta, id_rarita_carta),
  ADD CONSTRAINT fk_s_presenta_1 FOREIGN KEY (seriale) REFERENCES busta(seriale) ON UPDATE CASCADE ON DELETE CASCADE,
  ADD CONSTRAINT fk_s_presenta_2 FOREIGN KEY (id_carta, id_rarita_carta) REFERENCES carta(id, id_rarita) ON UPDATE CASCADE ON DELETE CASCADE;

-- 020
-- acquistata
ALTER TABLE acquistata
	ADD PRIMARY KEY (seriale, id_utente),
  ADD CONSTRAINT fk_acquista_1 FOREIGN KEY (seriale) REFERENCES busta(seriale) ON UPDATE CASCADE ON DELETE CASCADE,
  ADD CONSTRAINT fk_acquista_2 FOREIGN KEY (id_utente) REFERENCES utente(id) ON UPDATE CASCADE ON DELETE CASCADE;

-- 021
-- n_presenta
ALTER TABLE n_presenta
	ADD PRIMARY KEY (seriale, id_carta, id_rarita_carta),
  ADD CONSTRAINT fk_n_presenta_1 FOREIGN KEY (seriale) REFERENCES busta(seriale) ON UPDATE CASCADE ON DELETE CASCADE,
  ADD CONSTRAINT fk_n_presenta_2 FOREIGN KEY (id_carta, id_rarita_carta) REFERENCES carta(id, id_rarita) ON UPDATE CASCADE ON DELETE CASCADE;

-- 022
-- categoria
ALTER TABLE categoria
	ADD PRIMARY KEY (id),
  ADD CONSTRAINT unica_categoria UNIQUE (nome);

-- 023
-- magie_trappole
ALTER TABLE magie_trappole
	ADD PRIMARY KEY (id_carta, id_rarita_carta),
  ADD CONSTRAINT fk_magie_trappole_1 FOREIGN KEY (id_carta, id_rarita_carta) REFERENCES carta(id, id_rarita) ON UPDATE CASCADE ON DELETE CASCADE,
  ADD CONSTRAINT fk_magie_trappole_2 FOREIGN KEY (id_categoria) REFERENCES categoria(id) ON UPDATE CASCADE ON DELETE CASCADE;

-- 024
-- attributo
ALTER TABLE attributo
	ADD PRIMARY KEY (id),
  ADD CONSTRAINT unica_attributo UNIQUE (nome);

-- 025
-- sotto_tipo
ALTER TABLE sotto_tipo
	ADD PRIMARY KEY (id),
  ADD CONSTRAINT unica_sotto_tipo UNIQUE (nome);

-- 026
-- mostro
ALTER TABLE mostro
	ADD PRIMARY KEY (id_carta, id_rarita_carta),
  ADD CONSTRAINT fk_mostro_1 FOREIGN KEY (id_carta, id_rarita_carta) REFERENCES carta(id, id_rarita) ON UPDATE CASCADE ON DELETE CASCADE,
  ADD CONSTRAINT fk_mostro_2 FOREIGN KEY (id_sotto_tipo) REFERENCES sotto_tipo(id) ON UPDATE CASCADE ON DELETE CASCADE,
  ADD CONSTRAINT fk_mostro_3 FOREIGN KEY (id_attributo) REFERENCES attributo(id) ON UPDATE CASCADE ON DELETE CASCADE;
