-- seleziona tutte le partite classificate vinte dell'utente
SELECT
    u.nickname AS vincitore, u.elo, c.data, c.premio, (u.elo+c.premio) AS nuovo_elo
FROM
    utente AS u, classificata AS c
WHERE
   c.id_utente_vincitore=u.id AND c.id_utente_vincitore=1;
   
-- seleziona tutte le carte con le relative apparizioni e possessore 
SELECT
    u.nickname AS possessore, c.nome AS nome_carta, r.nome AS rarita_carta, a.n AS quantita
FROM
    carta AS c, rarita AS r, mazzo AS m, apparizioni AS a, carta_collezione AS cc, utente AS u
WHERE 
    u.id=cc.id_utente AND cc.id_carta=c.id AND cc.id_rarita_carta=c.id_rarita AND
    c.id_rarita=r.id AND a.id_utente_carta_coll=cc.id_utente AND
    a.id_carta_carta_coll=cc.id_carta AND a.id_rarita_carta_coll=cc.id_rarita_carta
GROUP BY
    u.nickname, c.nome, r.nome, a.n;

-- seleziono tutti gli utente che non hanno mai vinto una partita classificata
SELECT
    u.nome, u.nickname, r.nome AS rank, u.elo, u.gemme
FROM
    utente AS u, rank AS r
WHERE u.id_rank=r.id AND NOT EXISTS
    (SELECT *
     FROM classificata AS c
     WHERE c.id_utente_vincitore=u.id);
     
-- seleziona tutte le carte che sono di tipo mostro_effetto, non sono di sotto_tipo=normale e non hanno attributo=luce
SELECT
    c.nome AS nome_carta, st.nome AS sotto_tipo, a.nome AS attributo, r.nome AS rarita_carta
FROM
    carta AS c, rarita AS r, mostro AS m, sotto_tipo AS st, attributo AS a
WHERE 
    c.id=m.id_carta AND c.id_rarita=r.id AND
    m.id_sotto_tipo=st.id AND m.id_attributo=a.id AND
    m.tipologia_mostro_livello='mostro_effetto' AND
    NOT EXISTS
        (SELECT
            *
         FROM
            sotto_tipo AS st2
         WHERE
            m.id_sotto_tipo=st2.id AND st2.nome='normale'
        ) AND NOT EXISTS
        (SELECT
            *
         FROM
            attributo AS a2
         WHERE
            m.id_attributo=a2.id AND a2.nome='luce'
        );
