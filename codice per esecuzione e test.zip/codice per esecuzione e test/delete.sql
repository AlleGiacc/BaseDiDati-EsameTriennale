-- elimina una busta comprata in una determinata data facendo partire il DELETE CASCADE per la tabella venire
DELETE FROM comprare WHERE data='2022-07-26';
