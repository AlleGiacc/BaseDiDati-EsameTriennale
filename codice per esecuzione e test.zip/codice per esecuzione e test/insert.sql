-- QUERY INSERT
--
INSERT INTO rank(nome, range_min, range_max) VALUES
		('rookie', 0, 199),
		('bronze', 200, 699),
		('silver', 700, 1199),
		('gold', 1200, 1699),
		('platinum', 1700, 9999);
		
INSERT INTO utente(id_rank, nome, nickname, gemme, elo) VALUES
                  (2, 'Federico', 'Fede', 0, 500),
                  (1, 'Gabriele', 'Cuso', 156, 180),
                  (4, 'Alessandro', 'Giacco', 862, 1456);
                  
INSERT INTO amicizia(id_utente_1, id_utente_2) VALUES
		    (1, 3),
                    (1, 2);
                   
INSERT INTO amichevole(id_utente_vincitore, data) VALUES
                      (3, '2021-02-28'),
                      (1, '2020-07-15');
                      
INSERT INTO torneo(id) VALUES
                  (1),
                  (2),
                  (3),
                  (4);
                  
INSERT INTO classificata(id_utente_vincitore, id_torneo, data, premio) VALUES
                        (3, 1, '2021-08-14', 500),
                        (1, 2, '2020-12-15', 500),
                        (1, 3, '2022-01-28', 1000),
                        (3, 4, '2018-08-28', 1000);

INSERT INTO partecipa_classificata(id_utente, id_classificata) VALUES
				  (1, 1),
				  (2, 1),
				  (3, 1), 
				  (1, 2),
				  (2, 2),
				  (3, 2);

INSERT INTO mazzo(id_utente, nome, n_carte) VALUES
                 (1, 'EROE Elementale', 55),
                 (1, 'Exodia', 40),
                 (2, 'Drago Bianco Occhi Blu', 40),
                 (2, 'NEOS', 40),
                 (3, 'Fantasmatrucco', 40),
                 (3, 'Drago Polvere di Stelle', 40);
                 
INSERT INTO rarita(nome) VALUES
                  ('Ultra'),
                  ('Secret'),
                  ('Ultimate');
                  
INSERT INTO carta(id_rarita, nome) VALUES
                 (1, 'Elemental HERO Neos'),
                 (1, 'Yubel'),
                 (1, 'Elemental HERO Spirit of Neos'),
                 (1, 'Elemental HERO Honest Neos'),
                 (1, 'Elemental HERO Neos Alius'),
                 (3, 'Elemental HERO Stratos'),
                 (3, 'Elemental HERO Liquid Soldier'),
                 (3, 'Elemental HERO Solid Soldier'),
                 (3, 'Elemental HERO Blazeman'),
                 (2, 'Elemental HERO Shadow Mist'),
                 (2, 'Neo Space Connector'),
                 (2, 'Wroughtweiler'),
                 (3, 'A Hero Lives'),
                 (3, 'Neos Fusion'),
                 (2, 'Fusion Recovery'),
                 (2, 'Polymerization'),
                 (2, 'Legacy of a HERO'),
                 (2, 'Miracle Fusion'),
                 (2, 'Fifth Hope'),
                 (2, 'Hero Signal'),
                 (2, 'Elemental Recharge'),
                 (2, 'Magistery Alchemist'),
                 (2, 'Elemental HERO Neos Kluger'),
                 (2, 'Elemental HERO Great Tornado'),
                 (2, 'Elemental HERO Nova Master'),
                 (2, 'Elemental HERO The Shining'),
                 (1, 'Elemental HERO Escuridao'),
                 (1, 'Elemental HERO Absolute Zero'),
                 (2, 'Elemental HERO Brave Neos'),
                 (2, 'Elemental HERO Sunrise'),
                 (1, 'Elemental HERO Neos Knight'),
                 (2, 'Elemental HERO Gaia'),
                 (2, 'Elemental HERO Grandmerge'),
                 (1, 'Xtra HERO Dread Decimator'),
                 (1, 'Elemental HERO Stratos'),
                 (1, 'Elemental HERO Liquid Soldier'),
                 (1, 'Elemental HERO Solid Soldier'),
                 (1, 'Elemental HERO Blazeman'),
                 (1, 'Fusion Recovery'),
                 (1, 'Polymerization'),
                 (1, 'Legacy of a HERO'),
                 (1, 'Miracle Fusion'),
                 (1, 'Fifth Hope'),
                 (1, 'Hero Signal'),
                 (3, 'Polymerization');
                 
 INSERT INTO carta_collezione(id_utente, id_carta, id_rarita_carta, qnt) VALUES
                            (3, 1, 1, 3),
                            (3, 2, 1, 1),
                            (3, 3, 1, 2),
                            (3, 4, 1, 2),
                            (3, 5, 1, 2),
                            (3, 6, 3, 2),
                            (3, 7, 3, 2),
                            (3, 8, 3, 2),
                            (3, 9, 3, 2),
                            (3, 10, 2, 2),
                            (3, 11, 2, 2),
                            (3, 12, 2, 1),
                            (3, 13, 3, 1),
                            (3, 14, 3, 3),
                            (3, 15, 2, 1),
                            (3, 16, 2, 3),
                            (3, 17, 2, 1),
                            (3, 18, 2, 1),
                            (3, 19, 2, 2),
                            (3, 20, 2, 2),
                            (3, 21, 2, 1),
                            (3, 22, 2, 2),
                            (3, 23, 2, 1),
                            (3, 24, 2, 1),
                            (3, 25, 2, 1),
                            (3, 26, 2, 1),
                            (3, 27, 1, 1),
                            (3, 28, 1, 1),
                            (3, 29, 2, 1),
                            (3, 30, 2, 1),
                            (3, 31, 1, 3),
                            (3, 32, 2, 1),
                            (3, 33, 2, 2),
                            (3, 34, 1, 1),
                            (3, 35, 1, 1),
                            (3, 36, 1, 1),
                            (1, 15, 2, 1),
                            (1, 45, 3, 2);

INSERT INTO mercato (id_utente, id_utente_carta_coll, id_carta_carta_coll, id_rarita_carta_coll, qnt, prezzo) VALUES
                    (3, 3, 5, 1, 1, 50),
                    (3, 3, 8, 3, 1, 50),
                    (1, 1, 15, 2, 1, 75),
                    (1, 1, 45, 3, 1, 75);
                    
INSERT INTO apparizioni (id_mazzo, id_utente_carta_coll, id_carta_carta_coll, id_rarita_carta_coll, n) VALUES
			(1, 3, 5, 1, 2),
                        (1, 3, 8, 3, 3),
                        (1, 3, 4, 1, 1),
                        (1, 3, 3, 1, 1),
                        (1, 3, 2, 1, 1),
                        (1, 3, 1, 1, 1);   

INSERT INTO espansione(nome, anno) VALUES
                      ('Eroe Elementale', 2000),
                      ('Tempesta Occhi Blu', 2005);

INSERT INTO compare(id_espansione, id_carta, id_rarita_carta) VALUES
                    (1, 1, 1),
                    (1, 2, 1),
                    (1, 3, 1),
                    (1, 4, 1);

INSERT INTO busta(seriale, id_espansione, is_speciale) VALUES
                 ('CHACHA2000', 1, true),
                 ('VARVAR2005', 2, false);

INSERT INTO comprare(data, id_utente) VALUES
                    ('2019-05-18', 3),
                    ('2019-12-25', 3);
                    
INSERT INTO venire(seriale_busta, id_utente_comprare, data_comprare) VALUES
                  ('CHACHA2000', 3, '2019-05-18'),
                  ('CHACHA2000', 3, '2019-12-25');
                  
INSERT INTO s_presenta(seriale, id_carta, id_rarita_carta) VALUES
                      ('CHACHA2000', 1, 1),
                      ('CHACHA2000', 2, 1),
                      ('CHACHA2000', 3, 1),
                      ('CHACHA2000', 4, 1);
                      
INSERT INTO acquistata(seriale, id_utente) VALUES
                      ('CHACHA2000', 3),
                      ('CHACHA2000', 1);
                      
INSERT INTO categoria(nome) VALUES
                     ('normale'),
                     ('continua'),
                     ('terreno'),
                     ('rapida');
                     
INSERT INTO magie_trappole(id_carta, id_rarita_carta, id_categoria) VALUES
                          (13, 3, 1),
                          (14, 3, 1),
                          (15, 2, 1);
                          
INSERT INTO attributo(nome) VALUES
                     ('acqua'),
                     ('luce'),
                     ('fuoco'),
                     ('oscurità'),
                     ('vento'),
                     ('terra');
                     
INSERT INTO sotto_tipo(nome) VALUES
                      ('normale'),
                      ('guerriero'),
                      ('bestia alata');
                      
INSERT INTO mostro(id_carta, id_rarita_carta, tipologia_mostro, tipologia_mostro_livello, id_sotto_tipo, id_attributo) VALUES
                  (1, 1, 'livello', 'mostro_effetto', 1, 2),
                  (3, 1, 'livello', 'mostro_effetto', 2, 2),
                  (4, 1, 'livello', 'mostro_effetto', 2, 5),
                  (23, 2, 'xyz', 'mostro_normale', 1, 1),
         	  (24, 2, 'xyz', 'mostro_normale', 2, 1),
                  (25, 2, 'xyz', 'mostro_fusione', 2, 3),
                  (26, 2, 'link', 'mostro_fusione', 1, 3),
                  (27, 1, 'link', 'mostro_fusione', 3, 4),
                  (28, 1, 'livello', 'mostro_normale', 2, 2),
                  (29, 2, 'livello', 'mostro_normale', 3, 3),
                  (5, 1, 'livello', 'mostro_effetto', 2, 2),
                  (8, 3, 'livello', 'mostro_effetto', 2, 4);

