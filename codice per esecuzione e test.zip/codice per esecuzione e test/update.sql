-- aggiorna il numero di apparizioni di una carta facendo partire il trigger che lo blocca (non si è fatta la prova su rarità)
UPDATE apparizioni SET n=4 WHERE id_carta_carta_coll=1

-- aggiorna l'elo di un utente facendo partire il trigger che aggiorna l'id_rank
UPDATE utente SET elo=680 WHERE nickname='Cuso';

-- aggiorna il numero di carte all'interno i un mazzo facendo partire il trigger che lo blocca (limite min = 40 e limite_max = 60)
UPDATE mazzo SET n_carte=4 WHERE nome='Fantasmatrucco';
